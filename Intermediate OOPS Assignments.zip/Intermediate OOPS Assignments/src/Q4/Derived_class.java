package Q4;

public class Derived_class extends Main{
//in chaild class we need ti provide implementation to abstract method
	@Override
	public void meth() {
		// TODO Auto-generated method stub
		
	}

}
