package string_buffer_assignments;

public class Q3 {
public static void main(String[] args) {
	StringBuffer s=new StringBuffer("This method return a reversed object on it was called");
	System.out.println(s.reverse());
	
}
}
