package string_buffer_assignments;

public class Q1 {
	public static void main(String[] args) {
		StringBuffer string=new StringBuffer();
		string.append("StringBuffer ").append("is a peer class of string ").append("that provide much of ").append("the fucationality of string ");
		System.out.println(string);
	}

}
