package string_buffer_assignments;

public class Q2 {
public static void main(String[] args) {
	StringBuffer s1=new StringBuffer("it is used to _ at the spacified index position");
	StringBuffer s2=new StringBuffer("insert text");
   int i=s1.indexOf("_");
    String a=s1.substring(0, i);
    String b=s1.substring(i+1, s1.length());
    System.out.println(a + s2+b);
}
}
