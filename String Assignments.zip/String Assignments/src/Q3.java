import java.util.Scanner;

public class Q3 {
public static void main(String[] args) {
	String s1="Java String pool refers a Collection of String which are stored in heap memory";
	System.out.println(s1.toLowerCase());
	System.out.println(s1.toUpperCase());
	System.out.println(s1.replace('a','$'));
	System.out.println(s1.contains("collection"));
	System.out.println(s1.equals("java string pool refers a collection of string which are stored in heap memory"));
	System.out.println(s1.equalsIgnoreCase("java string pool refers a collection of string which are stored in heap memory"));
}
}
