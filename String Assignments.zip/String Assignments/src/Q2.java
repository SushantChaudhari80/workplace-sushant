import java.util.Scanner;

public class Q2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String 1 :");
		String string1=sc.nextLine();
		System.out.println("Enter a String 2 :");
		String string2=sc.nextLine();
		System.out.println(string1.concat(string2));
	}
}
