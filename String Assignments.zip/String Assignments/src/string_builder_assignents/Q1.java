package string_builder_assignents;

public class Q1 {
	public static void main(String[] args) {
		StringBuilder string=new StringBuilder();
		string.append("StringBuffer ").append("is a peer class of string ").append("that provide much of ").append("the fucationality of string ");
		System.out.println(string);
	}

}
