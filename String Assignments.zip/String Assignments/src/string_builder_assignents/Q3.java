package string_builder_assignents;

public class Q3 {
public static void main(String[] args) {
	StringBuilder s=new StringBuilder("This method return a reversed object on it was called");
	System.out.println(s.reverse());
	
}
}
