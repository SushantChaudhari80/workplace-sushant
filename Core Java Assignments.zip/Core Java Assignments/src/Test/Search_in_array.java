package Test;

import java.util.Scanner;

public class Search_in_array {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int arr[]= {5,12,14,6,78,19,1,23,26,35,37,7,52,86,47};
	System.out.println("Enter a number : ");
	int m=sc.nextInt();
	for(int i=0;i<arr.length;i++) {
		if(arr[i]==m) {
			System.out.println("Given no is present in arr and its position is "+(i+1));
		}
	}
	
}
}
