package Q1;

public class Main {
public static void main(String[] args) {
	TreeMap<Long,Contact> map=new TreeMap<Long,Contact>();
}
}
