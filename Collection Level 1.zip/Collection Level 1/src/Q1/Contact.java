package Q1;

public class Contact {	
Long phone_no;
String name;
String mail;
enum Gender{
	Male,
	Female;
}

public Contact(Long phone_no, String name, String mail) {
	super();
	this.phone_no = phone_no;
	this.name = name;
	this.mail = mail;
}
public Long getPhone_no() {
	return phone_no;
}
public void setPhone_no(Long phone_no) {
	this.phone_no = phone_no;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMail() {
	return mail;
}
public void setMail(String mail) {
	this.mail = mail;
}

}
