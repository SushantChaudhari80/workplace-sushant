package com.example.sushant.student.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sushant.student.model.EmpModel;
import com.example.sushant.student.repository.EmpRepository;

import antlr.collections.List;

@Service
public class EmpService 
{
	@Autowired
	EmpRepository repo;

	public ArrayList<EmpModel> findall(){
		return  (ArrayList<EmpModel>)repo.findAll();
	}
}
