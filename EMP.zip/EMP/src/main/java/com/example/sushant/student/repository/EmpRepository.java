package com.example.sushant.student.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.sushant.student.model.EmpModel;

@Repository
public interface EmpRepository extends CrudRepository<EmpModel, String>{

}
